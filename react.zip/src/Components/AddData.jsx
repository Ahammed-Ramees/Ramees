import React from 'react'

const AddData = () => {
  return (
    <div style={{paddingTop:"80px"}}>AddData</div>
  )
}

export default AddData