import React from 'react'

const AppData = () => {
  return (
    <div></div>
  )
}

export default AppData